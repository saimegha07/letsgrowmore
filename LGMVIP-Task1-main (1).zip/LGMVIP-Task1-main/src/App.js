import "./App.css";
import ViewItems from "./ViewItems";

function App() {
  return (
    <div className="App">
      <ViewItems />
    </div>
  );
}

export default App;
